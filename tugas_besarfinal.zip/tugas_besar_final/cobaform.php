<form>
<tr> id_barang</tr>
<tr> : </tr>
<tr> input type ="text"</tr>

 </form>